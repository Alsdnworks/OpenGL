#include "mesh.h"

MeshUPtr Mesh::Create(
  const std::vector<Vertex>& vertices,
  const std::vector<uint32_t>& indices,
  uint32_t primitiveType) {
  auto mesh = MeshUPtr(new Mesh());
  mesh->Init(vertices, indices, primitiveType);
  return std::move(mesh);
}//유니크포인터로 만들어 초기화해다 리턴하는 방식 사용

void Mesh::Init(
  const std::vector<Vertex>& vertices,
  const std::vector<uint32_t>& indices,
  uint32_t primitiveType) {
  m_vertexLayout = VertexLayout::Create();
  m_vertexBuffer = Buffer::CreateWithData(
    GL_ARRAY_BUFFER, GL_STATIC_DRAW,
    vertices.data(), sizeof(Vertex), vertices.size());//VBO
  m_indexBuffer = Buffer::CreateWithData(
    GL_ELEMENT_ARRAY_BUFFER, GL_STATIC_DRAW,
    indices.data(), sizeof(uint32_t), indices.size());//IBO
  m_vertexLayout->SetAttrib(0, 3, GL_FLOAT, false,
    sizeof(Vertex), 0);//position
  m_vertexLayout->SetAttrib(1, 3, GL_FLOAT, false,
    sizeof(Vertex), offsetof(Vertex, normal));//nomal
  m_vertexLayout->SetAttrib(2, 2, GL_FLOAT, false,
    sizeof(Vertex), offsetof(Vertex, texCoord));//texcoord
}
void Mesh::Draw(const Program* program) const { //VAO binding
  m_vertexLayout->Bind();
   if (m_material) {
    m_material->SetToProgram(program);
  }
  glDrawElements(m_primitiveType, m_indexBuffer->GetCount(),GL_UNSIGNED_INT, 0);
}

MeshUPtr Mesh::CreateBox() {
  std::vector<Vertex> vertices = {
    Vertex { glm::vec3(-0.5f, -0.5f, -0.5f), glm::vec3( 0.0f,  0.0f, -1.0f), glm::vec2(0.0f, 0.0f) },
    Vertex { glm::vec3( 0.5f, -0.5f, -0.5f), glm::vec3( 0.0f,  0.0f, -1.0f), glm::vec2(1.0f, 0.0f) },
    Vertex { glm::vec3( 0.5f,  0.5f, -0.5f), glm::vec3( 0.0f,  0.0f, -1.0f), glm::vec2(1.0f, 1.0f) },
    Vertex { glm::vec3(-0.5f,  0.5f, -0.5f), glm::vec3( 0.0f,  0.0f, -1.0f), glm::vec2(0.0f, 1.0f) },

    Vertex { glm::vec3(-0.5f, -0.5f,  0.5f), glm::vec3( 0.0f,  0.0f,  1.0f), glm::vec2(0.0f, 0.0f) },
    Vertex { glm::vec3( 0.5f, -0.5f,  0.5f), glm::vec3( 0.0f,  0.0f,  1.0f), glm::vec2(1.0f, 0.0f) },
    Vertex { glm::vec3( 0.5f,  0.5f,  0.5f), glm::vec3( 0.0f,  0.0f,  1.0f), glm::vec2(1.0f, 1.0f) },
    Vertex { glm::vec3(-0.5f,  0.5f,  0.5f), glm::vec3( 0.0f,  0.0f,  1.0f), glm::vec2(0.0f, 1.0f) },

    Vertex { glm::vec3(-0.5f,  0.5f,  0.5f), glm::vec3(-1.0f,  0.0f,  0.0f), glm::vec2(1.0f, 0.0f) },
    Vertex { glm::vec3(-0.5f,  0.5f, -0.5f), glm::vec3(-1.0f,  0.0f,  0.0f), glm::vec2(1.0f, 1.0f) },
    Vertex { glm::vec3(-0.5f, -0.5f, -0.5f), glm::vec3(-1.0f,  0.0f,  0.0f), glm::vec2(0.0f, 1.0f) },
    Vertex { glm::vec3(-0.5f, -0.5f,  0.5f), glm::vec3(-1.0f,  0.0f,  0.0f), glm::vec2(0.0f, 0.0f) },

    Vertex { glm::vec3( 0.5f,  0.5f,  0.5f), glm::vec3( 1.0f,  0.0f,  0.0f), glm::vec2(1.0f, 0.0f) },
    Vertex { glm::vec3( 0.5f,  0.5f, -0.5f), glm::vec3( 1.0f,  0.0f,  0.0f), glm::vec2(1.0f, 1.0f) },
    Vertex { glm::vec3( 0.5f, -0.5f, -0.5f), glm::vec3( 1.0f,  0.0f,  0.0f), glm::vec2(0.0f, 1.0f) },
    Vertex { glm::vec3( 0.5f, -0.5f,  0.5f), glm::vec3( 1.0f,  0.0f,  0.0f), glm::vec2(0.0f, 0.0f) },

    Vertex { glm::vec3(-0.5f, -0.5f, -0.5f), glm::vec3( 0.0f, -1.0f,  0.0f), glm::vec2(0.0f, 1.0f) },
    Vertex { glm::vec3( 0.5f, -0.5f, -0.5f), glm::vec3( 0.0f, -1.0f,  0.0f), glm::vec2(1.0f, 1.0f) },
    Vertex { glm::vec3( 0.5f, -0.5f,  0.5f), glm::vec3( 0.0f, -1.0f,  0.0f), glm::vec2(1.0f, 0.0f) },
    Vertex { glm::vec3(-0.5f, -0.5f,  0.5f), glm::vec3( 0.0f, -1.0f,  0.0f), glm::vec2(0.0f, 0.0f) },

    Vertex { glm::vec3(-0.5f,  0.5f, -0.5f), glm::vec3( 0.0f,  1.0f,  0.0f), glm::vec2(0.0f, 1.0f) },
    Vertex { glm::vec3( 0.5f,  0.5f, -0.5f), glm::vec3( 0.0f,  1.0f,  0.0f), glm::vec2(1.0f, 1.0f) },
    Vertex { glm::vec3( 0.5f,  0.5f,  0.5f), glm::vec3( 0.0f,  1.0f,  0.0f), glm::vec2(1.0f, 0.0f) },
    Vertex { glm::vec3(-0.5f,  0.5f,  0.5f), glm::vec3( 0.0f,  1.0f,  0.0f), glm::vec2(0.0f, 0.0f) },
  };

  std::vector<uint32_t> indices = {
     0,  2,  1,  2,  0,  3,
     4,  5,  6,  6,  7,  4,
     8,  9, 10, 10, 11,  8,
    12, 14, 13, 14, 12, 15,
    16, 17, 18, 18, 19, 16,
    20, 22, 21, 22, 20, 23,
  };
  
  return Create(vertices, indices, GL_TRIANGLES);
}

MeshUPtr Mesh::CreatePlane() {
  std::vector<Vertex> vertices = {
    Vertex { glm::vec3(-0.5f, -0.5f, 0.0f), glm::vec3( 0.0f,  0.0f, 1.0f), glm::vec2(0.0f, 0.0f) },
    Vertex { glm::vec3( 0.5f, -0.5f, 0.0f), glm::vec3( 0.0f,  0.0f, 1.0f), glm::vec2(1.0f, 0.0f) },
    Vertex { glm::vec3( 0.5f,  0.5f, 0.0f), glm::vec3( 0.0f,  0.0f, 1.0f), glm::vec2(1.0f, 1.0f) },
    Vertex { glm::vec3(-0.5f,  0.5f, 0.0f), glm::vec3( 0.0f,  0.0f, 1.0f), glm::vec2(0.0f, 1.0f) },
  };

  std::vector<uint32_t> indices = {
    0,  1,  2,  2,  3,  0,
  };

  return Create(vertices, indices, GL_TRIANGLES);
}//삼각형 2개로 만드는 1개 평면

void Material::SetToProgram(const Program* program) const {
  int textureCount = 1;
  if (diffuse) {
    glActiveTexture(GL_TEXTURE0 + textureCount);
    program->SetUniform("material.diffuse", textureCount);
    diffuse->Bind();
    textureCount++;
  }
  if (specular) {
    glActiveTexture(GL_TEXTURE0 + textureCount);
    program->SetUniform("material.specular", textureCount);
    specular->Bind();
    textureCount++;
  }
  glActiveTexture(GL_TEXTURE0);
  program->SetUniform("material.shininess", shininess);
}